/* Mathura Meal Market — configuration.
   Leave SUPABASE_* empty to run in DEMO MODE (data stays in this browser only).
   The anon key is SAFE to publish (access is limited by row-level security).
   NEVER put a Supabase service_role key in this file or anywhere in browser code. */
window.MMM_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",
  // Public site address used for the QR code, poster and share message. Leave "" to use the current page address.
  SITE_URL: "",
  // Optional: your WhatsApp number for the "Questions?" link, digits only with country code, e.g. 919XXXXXXXXX
  WHATSAPP_CONTACT: "",
  PRIVACY_CONTACT: "your-email@example.com", // shown in the privacy notice for access/deletion requests
  PRIVACY_VERSION: "v1-2026-10",
  LOCALITIES: ["Krishna Nagar","Holi Gate","Bhuteshwar","Civil Lines","Govind Nagar","Vikas Nagar","Dampier Nagar","Vrindavan Road","Masani","Chhatikara","Jaisingh Pura","Other"]
};
